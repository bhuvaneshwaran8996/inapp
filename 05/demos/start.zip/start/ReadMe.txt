Thank you for watching this course.

You need to do the following steps to do if you want to run the app.

1. Replace the package name com.pluralsight.counting to your own package name.

2. Create your project in Google Play console and add in-app products and subsription.

3. Connect to Firebase
The google-services.json file is missing in this project.
You need to configure Firebase in this project to make it work.

4. Loal Purchase Verificaiton
If you want to test local purchase verification, you need to put your own Base-64 encoded RSA public key,
which is on Monetize -> Monetization setup page in Google Play Developer Console.

Good luck!