package com.pluralsight.counting.billing

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import com.android.billingclient.api.*
import com.pluralsight.counting.db.product.ProductRepository
import com.pluralsight.counting.db.purchase.PurchaseRecordRepository
import com.pluralsight.counting.util.Security

class BillingRepository private constructor(
    private val context: Context,
    private val productRepository: ProductRepository,
    private val purchaseRecordRepository: PurchaseRecordRepository,
    private val security: Security
) : LifecycleObserver,
    PurchasesUpdatedListener,
    BillingClientStateListener,
    SkuDetailsResponseListener {

    /**
     * Instantiate a new BillingClient instance.
     */
    private lateinit var billingClient: BillingClient

    companion object {
        private const val LOG_TAG = "BillingRepository"

        @Volatile
        private var INSTANCE: BillingRepository? = null

        fun getInstance(
            app: Context,
            productRepository: ProductRepository,
            purchaseRecordRepository: PurchaseRecordRepository,
            security: Security
        ): BillingRepository =
            INSTANCE ?: synchronized(this) {
                val billingRepository = INSTANCE ?: BillingRepository(
                    app,
                    productRepository,
                    purchaseRecordRepository,
                    security
                ).also { INSTANCE = it }
                billingRepository
            }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
    fun create() {
        // TODO: Create a new BillingClient in onCreate().
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun destroy() {
        // TODO: End connection on the billing client
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        // TODO: Add code here
    }

    /**
     * Launching the billing flow.
     *
     * Launching the UI to make a purchase requires a reference to the Activity.
     */
    fun launchBillingFlow(activity: Activity, skuDetails: SkuDetails): Int {
        // TODO: Add code here
        return 0
    }

    /**
     * This is to handle all the future purchases that complete when the app is open
     */
    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: MutableList<Purchase>?) {
        // TODO: Add code here
    }

    override fun onBillingServiceDisconnected() {
        Log.d(LOG_TAG, "onBillingServiceDisconnected()")
    }

    /**
     * Receives the result from [queryProducts].
     *
     * Store the SkuDetails and post them in the [skusWithSkuDetails]. This allows other parts
     * of the app to use the [SkuDetails] to show SKU information and make purchases.
     */
    override fun onSkuDetailsResponse(
        billingResult: BillingResult,
        skuDetailsList: MutableList<SkuDetails>?
    ) {
        // TODO: Add code here
    }

    fun acknowledgePurchase(purchaseToken: String) {
        // TODO: Add code here
    }

    fun consumePurchase(purchaseToken: String) {
        // TODO: Add code here
    }

    private fun queryProducts() {
        // TODO: Add code here
    }

    /**
     * In order to make purchases, you need the [SkuDetails] for the item or subscription.
     * This is an asynchronous call that will receive a result in [onSkuDetailsResponse].
     */
    private fun queryProducts(productType: String, skuList: List<String>) {
        // TODO: Add code here
    }
    /**
     * Query Google Play Billing for existing purchases.
     *
     * New purchases will be provided to the PurchasesUpdatedListener.
     * You still need to check the Google Play Billing API to know when purchase tokens are removed.
     */
    private fun queryPurchases() {
        queryPurchases(BillingClient.SkuType.SUBS)
        queryPurchases(BillingClient.SkuType.INAPP)
    }

    private fun queryPurchases(type: String) {
        // TODO: Add code here
    }

    private fun removeExpiredSubscription(type: String, result: Purchase.PurchasesResult) {
        // TODO: Add code here
    }

    private fun processPurchases(purchasesList: List<Purchase>?) {
        // TODO: Add code here
    }

    private fun verifyProductsOnCloud(purchase: Purchase) {
        // TODO: Add code here
    }

    private fun verifySubscriptionOnCloud(purchase: Purchase) {
        // TODO: Add code here
    }

    private fun savePurchaseLocally(purchasesList: List<Purchase>) {
        // TODO: Add code here
    }

    private fun isSignatureValid(purchase: Purchase): Boolean {
        return security.verifyPurchase(security.BASE_64_ENCODED_PUBLIC_KEY, purchase.originalJson, purchase.signature)
    }
}
