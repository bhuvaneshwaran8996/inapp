package com.pluralsight.counting.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.pluralsight.counting.BuildConfig
import com.pluralsight.counting.R
import com.pluralsight.counting.billing.Constants
import com.pluralsight.counting.servicelocator.ServiceLocator
import com.pluralsight.counting.util.viewModelFactory

class SettingsFragment : Fragment() {
    private lateinit var viewModel: SettingsViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_settings, container, false)
        val textViewGetPremiumFeature = root.findViewById<TextView>(R.id.textview_premium_features)
        textViewGetPremiumFeature.setOnClickListener {
            findNavController().navigate(R.id.purchase_dest, null, null)
        }
        val textViewMySubscription = root.findViewById<TextView>(R.id.textview_my_subscription)
        textViewMySubscription.setOnClickListener {
            openMonthlySubscriptionOnPlayStore()
        }
        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this,
            viewModelFactory { SettingsViewModel(ServiceLocator.purchaseRecordRepository) })
            .get(SettingsViewModel::class.java)
    }

    private fun openMonthlySubscriptionOnPlayStore() {
        val intent = Intent(Intent.ACTION_VIEW)
        val subscriptionUrl = String.format(Constants.PLAY_STORE_SUBSCRIPTION_DEEPLINK_URL,
            Constants.SUBSCRIPTION_SKU,
            BuildConfig.APPLICATION_ID)
        val url = if (viewModel.hasActiveSubscription()) subscriptionUrl
                    else Constants.PLAY_STORE_OTHER_SUBSCRIPTION_URL
        intent.data = Uri.parse(url)
        startActivity(intent)
    }
}
