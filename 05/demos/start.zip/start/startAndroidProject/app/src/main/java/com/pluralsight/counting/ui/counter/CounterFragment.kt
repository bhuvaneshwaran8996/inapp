package com.pluralsight.counting.ui.counter

import android.os.Bundle
import android.view.*
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.pluralsight.counting.R
import com.pluralsight.counting.model.CounterType
import com.pluralsight.counting.servicelocator.ServiceLocator
import com.pluralsight.counting.ui.home.HomeFragment
import com.pluralsight.counting.util.viewModelFactory

class CounterFragment : Fragment() {

    private lateinit var viewModel: CounterViewModel
    private lateinit var textViewStatus: TextView
    private lateinit var buttonIncrease: ImageView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        setHasOptionsMenu(true)
        val rootView = inflater.inflate(R.layout.fragment_counter, container, false)
        textViewStatus = rootView.findViewById(R.id.textview_status)
        buttonIncrease = rootView.findViewById(R.id.button_increase)

        buttonIncrease.setOnClickListener {
            if (viewModel.counterType == CounterType.NUMBER) {
                viewModel.increase()
                textViewStatus.text = viewModel.number.toString()
            } else {
                viewModel.handleTimer()
            }
        }

        val buttonSave = rootView.findViewById<TextView>(R.id.button_save)
        buttonSave.setOnClickListener {
            viewModel.save()
            Toast.makeText(requireActivity(), R.string.saved, Toast.LENGTH_LONG).show()
        }
        return rootView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this,
            viewModelFactory {
                CounterViewModel(
                    ServiceLocator.logRepository
                )
            }
        ).get(CounterViewModel::class.java)
        viewModel.counterId = arguments?.getString(HomeFragment.SELECTED_COUNTER_ID) ?: ""
        viewModel.counterName = arguments?.getString(HomeFragment.SELECTED_COUNTER_NAME) ?: ""
        viewModel.counterType = arguments?.getSerializable(HomeFragment.SELECTED_COUNTER_TYPE) as CounterType
        viewModel.countdownDuration = arguments?.getLong(HomeFragment.SELECTED_COUNTER_DURATION) ?: 0

        viewModel.countingText.observe(viewLifecycleOwner, Observer {
            textViewStatus.text = viewModel.countingText.value
        })
        viewModel.isCountingDown.observe(viewLifecycleOwner, Observer {
            this.buttonIncrease.setImageDrawable(viewModel.getDrawable(requireContext()))
        })
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_counter_actions, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.action_reset -> {
                viewModel.reset()
                textViewStatus.text = viewModel.number.toString()
                return true
            }
        }

        return super.onOptionsItemSelected(item)
    }
}
