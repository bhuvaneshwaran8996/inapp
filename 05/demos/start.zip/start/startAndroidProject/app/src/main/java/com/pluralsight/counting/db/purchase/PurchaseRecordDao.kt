package com.pluralsight.counting.db.purchase

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface PurchaseRecordDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(purchaseRecord: PurchaseRecord)

    @get:Query("SELECT * FROM purchase_log_table")
    val allPurchaseRecords: LiveData<List<PurchaseRecord>>

    @Query("DELETE FROM purchase_log_table WHERE sku = :sku")
    fun deletePurchase(sku: String)

    @Query("UPDATE purchase_log_table SET isAcknowledged = :isAcknowledged WHERE purchaseToken =:purchaseToken")
    fun updatePurchaseAcknowledged(purchaseToken: String, isAcknowledged: Boolean)

    @Query("UPDATE purchase_log_table SET isConsumed = :isConsumed WHERE purchaseToken =:purchaseToken")
    fun updatePurchaseConsumed(purchaseToken: String, isConsumed: Boolean)
}
