package com.pluralsight.counting.model

enum class CounterType {
    NUMBER,
    DURATION
}
