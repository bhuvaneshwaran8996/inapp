package com.pluralsight.counting.db.purchase

import android.content.Context
import androidx.annotation.WorkerThread
import androidx.lifecycle.LiveData
import com.android.billingclient.api.Purchase
import com.pluralsight.counting.db.localdb.CounterDatabase
import kotlinx.coroutines.*
import java.util.*

class PurchaseRecordRepository private constructor(private val application: Context) {
    private lateinit var counterDatabase: CounterDatabase

    companion object {
        private const val LOG_TAG = "PurchaseRecordRepository"

        @Volatile
        private var INSTANCE: PurchaseRecordRepository? = null

        fun getInstance(application: Context): PurchaseRecordRepository =
            INSTANCE
                ?: synchronized(this) {
                INSTANCE
                    ?: PurchaseRecordRepository(
                        application
                    )
                        .also { INSTANCE = it }
            }
    }

    val purchaseRecords: LiveData<List<PurchaseRecord>> by lazy {
        if (!::counterDatabase.isInitialized) {
            counterDatabase = CounterDatabase.getDatabase(application)
        }
        counterDatabase.purchaseDao().allPurchaseRecords
    }

    fun createPurchaseRecord(purchase: Purchase) {
        val scope = CoroutineScope(Job() + Dispatchers.IO)
        scope.launch {
            insert(
                PurchaseRecord(
                    purchase.purchaseToken,
                    purchase.sku,
                    purchase.signature,
                    purchase.purchaseTime,
                    purchase.purchaseState,
                    purchase.originalJson,
                    purchase.isAcknowledged,
                    purchase.isAutoRenewing,
                    false
                )
            )
        }
    }

    @WorkerThread
    private suspend fun insert(purchaseRecord: PurchaseRecord) = withContext(Dispatchers.IO) {
        if (!::counterDatabase.isInitialized) {
            counterDatabase = CounterDatabase.getDatabase(application)
        }
        counterDatabase.purchaseDao().insert(purchaseRecord)
    }

    fun acknowledgePurchase(purchaseToken: String) {
        val scope = CoroutineScope(Job() + Dispatchers.IO)
        scope.launch {
            updatePurchaseAcknowledged(purchaseToken, true)
        }
    }

    @WorkerThread
    private suspend fun updatePurchaseAcknowledged(purchaseToken: String, isAcknowledged: Boolean) =
            withContext(Dispatchers.IO) {
        if (!::counterDatabase.isInitialized) {
            counterDatabase = CounterDatabase.getDatabase(application)
        }
        counterDatabase.purchaseDao().updatePurchaseAcknowledged(purchaseToken, isAcknowledged)
    }

    fun consumePurchase(purchaseToken: String) {
        val scope = CoroutineScope(Job() + Dispatchers.IO)
        scope.launch {
            updatePurchaseConsumed(purchaseToken, true)
        }
    }

    @WorkerThread
    private suspend fun updatePurchaseConsumed(purchaseToken: String, isConsumed: Boolean) =
            withContext(Dispatchers.IO) {
        if (!::counterDatabase.isInitialized) {
            counterDatabase = CounterDatabase.getDatabase(application)
        }
        counterDatabase.purchaseDao().updatePurchaseConsumed(purchaseToken, isConsumed)
    }

    fun deletePurchase(sku: String) {
        val scope = CoroutineScope(Job() + Dispatchers.IO)
        scope.launch {
            deletePurchaseInDB(sku)
        }
    }

    @WorkerThread
    private suspend fun deletePurchaseInDB(sku: String) =
        withContext(Dispatchers.IO) {
            if (!::counterDatabase.isInitialized) {
                counterDatabase = CounterDatabase.getDatabase(application)
            }
            counterDatabase.purchaseDao().deletePurchase(sku)
        }
}
