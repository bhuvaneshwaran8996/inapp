package com.pluralsight.counting

import android.app.Application
import com.pluralsight.counting.servicelocator.ServiceLocator

class CountingApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.initialize(this)
    }
}
