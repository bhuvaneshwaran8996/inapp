package com.pluralsight.counting.ui.purchase

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.billingclient.api.SkuDetails
import com.pluralsight.counting.R
import com.pluralsight.counting.servicelocator.ServiceLocator
import com.pluralsight.counting.ui.purchase.recyclerview.PurchaseAdapter
import com.pluralsight.counting.util.viewModelFactory

class PurchaseFragment : Fragment() {
    private val LOG_TAG: String = this.javaClass.simpleName
    private var adapter: PurchaseAdapter = PurchaseAdapter { skuDetails: SkuDetails -> onProductClicked(skuDetails) }
    private lateinit var viewModel: PurchaseViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewModel = ViewModelProvider(this,
            viewModelFactory {
                PurchaseViewModel(
                    ServiceLocator.billingRepository,
                    ServiceLocator.productRepository,
                    ServiceLocator.purchaseRecordRepository
                )
            }
        ).get(PurchaseViewModel::class.java)
        val root = inflater.inflate(R.layout.purchase_fragment, container, false)
        val recyclerView = root.findViewById<RecyclerView>(R.id.fragment_purchase_recyclerview)
        context?.let {
            recyclerView.layoutManager = LinearLayoutManager(it)
            adapter = PurchaseAdapter { skuDetails: SkuDetails -> onProductClicked(skuDetails) }
            recyclerView.adapter = adapter
        }
        return root
    }

    private fun onProductClicked(skuDetails: SkuDetails) {
        viewModel.buy(skuDetails, requireActivity())
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel.products.observe(viewLifecycleOwner, Observer { products ->
            products.map { SkuDetails(it.jsonSkuDetails) }?.let { skuDetails ->
                Log.d(LOG_TAG, "Get skudetails ${skuDetails.size}")
                adapter.setSkuDetails(skuDetails)
            }
        })
        viewModel.purchaseRecords.observe(viewLifecycleOwner, Observer { purchaseRecords ->
            val sku = purchaseRecords.singleOrNull()?.sku
            Log.d(LOG_TAG, "Purchased $purchaseRecords, $sku")
            sku?.let {
                Toast.makeText(context, sku, Toast.LENGTH_LONG).show()
            }
        })
    }
}
