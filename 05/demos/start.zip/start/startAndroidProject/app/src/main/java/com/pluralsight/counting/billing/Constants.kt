package com.pluralsight.counting.billing

object Constants {
    // TODO: Change these to your own products
    const val CONSUMABLE_COUNTER_SKU = "YOUR_IN_APP_PRODUCT"
    const val NON_CONSUMABLE_TIMER_SKU = "YOUR_IN_APP_PRODUCT"
    const val SUBSCRIPTION_SKU = "YOUR_SUBSCRIPTION"
    const val PLAY_STORE_SUBSCRIPTION_DEEPLINK_URL =
            "https://play.google.com/store/account/subscriptions?sku=%s&package=%s"
    const val PLAY_STORE_OTHER_SUBSCRIPTION_URL = "https://play.google.com/store/account/subscriptions"
}
