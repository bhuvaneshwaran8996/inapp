package com.pluralsight.counting.db.counter

import android.content.Context
import androidx.annotation.WorkerThread
import androidx.lifecycle.LiveData
import com.pluralsight.counting.db.localdb.CounterDatabase
import com.pluralsight.counting.model.CounterType
import kotlinx.coroutines.*
import java.util.*

class CounterRepository private constructor(private val application: Context) {
    private lateinit var counterDatabase: CounterDatabase

    companion object {

        @Volatile
        private var INSTANCE: CounterRepository? = null

        fun getInstance(application: Context): CounterRepository =
            INSTANCE
                ?: synchronized(this) {
                INSTANCE
                    ?: CounterRepository(
                        application
                    )
                        .also { INSTANCE = it }
            }
    }

    val counters: LiveData<List<Counter>> by lazy {
        if (!::counterDatabase.isInitialized) {
            counterDatabase = CounterDatabase.getDatabase(application)
        }
        counterDatabase.counterDao().allCounters
    }

    fun createCounter(
        name: String,
        duration: Long,
        type: CounterType = CounterType.NUMBER
    ) {
        val scope = CoroutineScope(Job() + Dispatchers.IO)
        scope.launch {
            val id = UUID.randomUUID().toString()
            insert(
                Counter(
                    id,
                    name,
                    duration,
                    type.ordinal
                )
            )
        }
    }

    @WorkerThread
    private suspend fun insert(counter: Counter) = withContext(Dispatchers.IO) {
        if (!::counterDatabase.isInitialized) {
            counterDatabase = CounterDatabase.getDatabase(application)
        }
        counterDatabase.counterDao().insert(counter)
    }
}
