package com.pluralsight.counting.db.counter

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "counter_table", indices = [Index("id"), Index("name")])
class Counter(
    @PrimaryKey val id: String,
    val name: String,
    val countDownDuration: Long,
    val type: Int
)
