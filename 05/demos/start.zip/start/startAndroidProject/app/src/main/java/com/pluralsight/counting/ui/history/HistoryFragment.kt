package com.pluralsight.counting.ui.history

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pluralsight.counting.R
import com.pluralsight.counting.db.log.Log
import com.pluralsight.counting.servicelocator.ServiceLocator
import com.pluralsight.counting.ui.history.recyclerview.HistoryItemAdapter
import com.pluralsight.counting.util.viewModelFactory

class HistoryFragment : Fragment() {

    private lateinit var viewModel: HistoryViewModel
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: HistoryItemAdapter
    private lateinit var textView: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_history, container, false)
        textView = root.findViewById(R.id.fragment_history_text_empty_list)
        recyclerView = root.findViewById(R.id.fragment_history_recyclerview)
        context?.let {
            recyclerView.layoutManager = LinearLayoutManager(context)
            adapter = HistoryItemAdapter()
            recyclerView.adapter = adapter
        }
        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this,
            viewModelFactory {
                HistoryViewModel(
                    ServiceLocator.logRepository,
                    ServiceLocator.purchaseRecordRepository,
                    ServiceLocator.billingRepository
                )
            }
        ).get(HistoryViewModel::class.java)
        viewModel.purchaseRecords.observe(viewLifecycleOwner, Observer {
            if (viewModel.hasSubscribed) {
                viewModel.acknowledgePurchase()
                viewModel.logs.value?.let { logs ->
                    showLogs(logs)
                }
            } else {
                textView.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
            }
        })
        viewModel.logs.observe(viewLifecycleOwner, Observer { logs ->
            if (viewModel.hasSubscribed) {
                showLogs(logs)
            }
        })
    }

    private fun showLogs(logs: List<Log>) {
        adapter.setLogs(logs)
        textView.visibility =
            if (viewModel.logs.value?.size ?: 0 > 0) View.GONE else View.VISIBLE
        textView.text = context?.getString(R.string.no_log) ?: ""
    }
}
