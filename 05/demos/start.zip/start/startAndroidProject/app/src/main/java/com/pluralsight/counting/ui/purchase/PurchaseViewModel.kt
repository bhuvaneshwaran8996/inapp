package com.pluralsight.counting.ui.purchase

import android.app.Activity
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.android.billingclient.api.SkuDetails
import com.pluralsight.counting.billing.BillingRepository
import com.pluralsight.counting.db.product.Product
import com.pluralsight.counting.db.product.ProductRepository
import com.pluralsight.counting.db.purchase.PurchaseRecord
import com.pluralsight.counting.db.purchase.PurchaseRecordRepository

class PurchaseViewModel(
    private val billingRepository: BillingRepository,
    productRepository: ProductRepository,
    purchaseRecordRepository: PurchaseRecordRepository
) : ViewModel() {
    val purchaseRecords: LiveData<List<PurchaseRecord>> = purchaseRecordRepository.purchaseRecords
    val products: LiveData<List<Product>> = productRepository.products

    fun buy(skuDetails: SkuDetails, activity: Activity) {
        billingRepository.launchBillingFlow(activity, skuDetails)
    }
}
