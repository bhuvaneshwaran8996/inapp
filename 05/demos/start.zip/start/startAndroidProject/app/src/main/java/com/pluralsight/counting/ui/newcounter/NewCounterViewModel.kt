package com.pluralsight.counting.ui.newcounter

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.pluralsight.counting.billing.BillingRepository
import com.pluralsight.counting.billing.Constants
import com.pluralsight.counting.db.counter.CounterRepository
import com.pluralsight.counting.db.purchase.PurchaseRecord
import com.pluralsight.counting.db.purchase.PurchaseRecordRepository
import com.pluralsight.counting.model.CounterType

class NewCounterViewModel(
    private val counterRepository: CounterRepository,
    purchaseRecordRepository: PurchaseRecordRepository,
    private val billingRepository: BillingRepository
) : ViewModel() {
    private val purchasedTimers: MutableLiveData<List<PurchaseRecord>> = MutableLiveData()
    val purchaseRecords = purchaseRecordRepository.purchaseRecords
    val hasPurchasedTimer: Boolean
            get() = purchasedTimers.value?.size ?: 0 > 0

    fun updatePurchasedTimers() {
        purchasedTimers.value =
            purchaseRecords.value?.filter { it.sku == Constants.NON_CONSUMABLE_TIMER_SKU }
    }

    fun acknowledgePurchase() {
        purchasedTimers.value?.firstOrNull()?.let { purchasedTimer ->
            if (!purchasedTimer.isAcknowledged) {
                billingRepository.acknowledgePurchase(purchasedTimer.purchaseToken)
            }
        }
    }

    fun saveCounter(name: String, duration: Long, type: CounterType) {
        counterRepository.createCounter(name, duration, type)
    }
}
