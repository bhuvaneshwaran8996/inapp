package com.pluralsight.counting.ui.home.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.pluralsight.counting.R
import com.pluralsight.counting.db.counter.Counter

class CounterAdapter(private val clickListener: (Counter) -> Unit) :
    RecyclerView.Adapter<CounterAdapter.ViewHolder>() {
    private var counters: List<Counter> = mutableListOf()

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var counterRowTextView: TextView = itemView.findViewById(R.id.counter_row_text)

        fun bind(counter: Counter, clickListener: (Counter) -> Unit) {
            counterRowTextView.text = counter.name
            itemView.setOnClickListener { clickListener(counter) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView: View = LayoutInflater.from(parent.context).inflate(R.layout.counter_row_item, parent, false)
        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return counters.count()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(counters[position], clickListener)
    }

    fun setCounters(counters: List<Counter>) {
        this.counters = counters
        notifyDataSetChanged()
    }
}
