package com.pluralsight.counting.ui.purchase.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.android.billingclient.api.SkuDetails
import com.pluralsight.counting.R

class PurchaseAdapter(private val productClickListener: (SkuDetails) -> Unit) :
    RecyclerView.Adapter<PurchaseAdapter.ViewHolder>() {
    private var skuDetails: List<SkuDetails> = mutableListOf()

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val productNameTextView: TextView = itemView.findViewById(R.id.textview_product_name)
        private val productDescriptionTextView: TextView = itemView.findViewById(R.id.textview_product_description)

        fun bind(skuDetails: SkuDetails, productClickListener: (SkuDetails) -> Unit) {
            productNameTextView.text = skuDetails.title
            productDescriptionTextView.text = skuDetails.description
            itemView.setOnClickListener { productClickListener(skuDetails) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView: View = LayoutInflater.from(parent.context).inflate(R.layout.purchase_row_item, parent, false)
        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return skuDetails.count()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(skuDetails[position], productClickListener)
    }

    fun setSkuDetails(skuDetails: List<SkuDetails>) {
        this.skuDetails = skuDetails
        notifyDataSetChanged()
    }
}
