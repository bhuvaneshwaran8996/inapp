package com.pluralsight.counting.db.log

import android.content.Context
import androidx.annotation.WorkerThread
import androidx.lifecycle.LiveData
import com.pluralsight.counting.db.localdb.CounterDatabase
import kotlinx.coroutines.*
import java.util.*

class LogRepository private constructor(private val application: Context) {
    private lateinit var counterDatabase: CounterDatabase

    companion object {

        @Volatile
        private var INSTANCE: LogRepository? = null

        fun getInstance(application: Context): LogRepository =
            INSTANCE
                ?: synchronized(this) {
                INSTANCE
                    ?: LogRepository(
                        application
                    )
                        .also { INSTANCE = it }
            }
    }

    val logs: LiveData<List<Log>> by lazy {
        if (!::counterDatabase.isInitialized) {
            counterDatabase = CounterDatabase.getDatabase(application)
        }
        counterDatabase.logDao().allLogs
    }

    fun createLog(
        counterId: String,
        counterName: String,
        count: Long?,
        duration: Long?,
        createdAt: Long
    ) {
        val scope = CoroutineScope(Job() + Dispatchers.IO)
        scope.launch {
            val id = UUID.randomUUID().toString()
            insert(
                Log(
                    id,
                    counterId,
                    counterName,
                    count,
                    duration,
                    createdAt
                )
            )
        }
    }

    @WorkerThread
    private suspend fun insert(log: Log) = withContext(Dispatchers.IO) {
        if (!::counterDatabase.isInitialized) {
            counterDatabase = CounterDatabase.getDatabase(application)
        }
        counterDatabase.logDao().insert(log)
    }
}
