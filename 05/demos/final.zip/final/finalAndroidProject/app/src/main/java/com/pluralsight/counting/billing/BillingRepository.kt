package com.pluralsight.counting.billing

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import com.android.billingclient.api.*
import com.google.firebase.functions.FirebaseFunctions
import com.pluralsight.counting.db.product.ProductRepository
import com.pluralsight.counting.db.purchase.PurchaseRecordRepository
import com.pluralsight.counting.util.Security
import java.util.HashMap

class BillingRepository private constructor(
    private val context: Context,
    private val productRepository: ProductRepository,
    private val purchaseRecordRepository: PurchaseRecordRepository,
    private val security: Security
) : LifecycleObserver,
    PurchasesUpdatedListener,
    BillingClientStateListener,
    SkuDetailsResponseListener {

    /**
     * Instantiate a new BillingClient instance.
     */
    private lateinit var billingClient: BillingClient

    companion object {
        private const val LOG_TAG = "BillingRepository"

        @Volatile
        private var INSTANCE: BillingRepository? = null

        fun getInstance(
            app: Context,
            productRepository: ProductRepository,
            purchaseRecordRepository: PurchaseRecordRepository,
            security: Security
        ): BillingRepository =
            INSTANCE ?: synchronized(this) {
                val billingRepository = INSTANCE ?: BillingRepository(
                    app,
                    productRepository,
                    purchaseRecordRepository,
                    security
                ).also { INSTANCE = it }
                billingRepository
            }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
    fun create() {
        Log.d(LOG_TAG, "ON_CREATE")
        // Create a new BillingClient in onCreate().
        // Since the BillingClient can only be used once, we need to create a new instance
        // after ending the previous connection to the Google Play Store in onDestroy().
        billingClient = BillingClient.newBuilder(context)
            .setListener(this)
            .enablePendingPurchases() // Not used for subscriptions.
            .build()
        if (!billingClient.isReady) {
            Log.d(LOG_TAG, "BillingClient: Start connection...")
            billingClient.startConnection(this)
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun destroy() {
        Log.d(LOG_TAG, "ON_DESTROY")
        if (billingClient.isReady) {
            Log.d(LOG_TAG, "BillingClient can only be used once -- closing connection")
            // BillingClient can only be used once.
            // After calling endConnection(), we must create a new BillingClient.
            billingClient.endConnection()
        }
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        val responseCode = billingResult.responseCode
        val debugMessage = billingResult.debugMessage
        Log.d(LOG_TAG, "onBillingSetupFinished: $responseCode $debugMessage")
        if (responseCode == BillingClient.BillingResponseCode.OK) {
            // The billing client is ready. You can query purchases here.
            queryProducts()
            queryPurchases()
        }
    }

    /**
     * Launching the billing flow.
     *
     * Launching the UI to make a purchase requires a reference to the Activity.
     */
    fun launchBillingFlow(activity: Activity, skuDetails: SkuDetails): Int {
        val billingBuilder = BillingFlowParams.newBuilder().setSkuDetails(skuDetails)
        val params: BillingFlowParams = billingBuilder.build()
        val sku = params.sku
        val oldSku = params.oldSku
        Log.i(LOG_TAG, "launchBillingFlow: sku: $sku, oldSku: $oldSku")
        if (!billingClient.isReady) {
            Log.e(LOG_TAG, "launchBillingFlow: BillingClient is not ready")
        }
        val billingResult = billingClient.launchBillingFlow(activity, params)
        val responseCode = billingResult.responseCode
        val debugMessage = billingResult.debugMessage

        when (responseCode) {
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> {
                Log.i(LOG_TAG, "launchBillingFlow: The user already owns this item")
            }
            else -> Log.d(LOG_TAG, "launchBillingFlow: BillingResponse responseCode: " +
                    "$responseCode debugMessage: $debugMessage")
        }
        return responseCode
    }

    /**
     * This is to handle all the future purchases that complete when the app is open
     */
    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: MutableList<Purchase>?) {
        val responseCode = billingResult.responseCode
        val debugMessage = billingResult.debugMessage
        Log.d(LOG_TAG, "onPurchasesUpdated: $responseCode $debugMessage")
        when (responseCode) {
            BillingClient.BillingResponseCode.OK -> {
                if (purchases == null) {
                    Log.d(LOG_TAG, "onPurchasesUpdated: null purchase list")
                    processPurchases(null)
                } else {
                    processPurchases(purchases)
                }
            }
            BillingClient.BillingResponseCode.USER_CANCELED -> {
                Log.i(LOG_TAG, "onPurchasesUpdated: User canceled the purchase")
            }
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> {
                Log.i(LOG_TAG, "onPurchasesUpdated: The user already owns this item")
            }
            BillingClient.BillingResponseCode.DEVELOPER_ERROR -> {
                Log.e(LOG_TAG, "onPurchasesUpdated: Developer error means that Google Play " +
                        "does not recognize the configuration. If you are just getting started, " +
                        "make sure you have configured the application correctly in the " +
                        "Google Play Console. The SKU product ID must match and the APK you " +
                        "are using must be signed with release keys."
                )
            }
        }
    }

    override fun onBillingServiceDisconnected() {
        Log.d(LOG_TAG, "onBillingServiceDisconnected()")
    }

    /**
     * Receives the result from [queryProducts].
     *
     * Store the SkuDetails and post them in the [skusWithSkuDetails]. This allows other parts
     * of the app to use the [SkuDetails] to show SKU information and make purchases.
     */
    override fun onSkuDetailsResponse(
        billingResult: BillingResult,
        skuDetailsList: MutableList<SkuDetails>?
    ) {
        val responseCode = billingResult.responseCode
        val debugMessage = billingResult.debugMessage
        when (responseCode) {
            BillingClient.BillingResponseCode.OK -> {
                Log.i(LOG_TAG, "onSkuDetailsResponse: responseCode: $responseCode debugMessage: $debugMessage")
                if (skuDetailsList == null) {
                    Log.w(LOG_TAG, "onSkuDetailsResponse: null SkuDetails list")
                } else {
                    for (details in skuDetailsList) {
                        productRepository.createProduct(details)
                        Log.i(LOG_TAG, "onSkuDetailsResponse: skuDetail: ${details.sku}, " +
                            "${details.title}, " +
                            "${details.description}, " +
                            "${details.price}, " +
                            "${details.priceCurrencyCode}")
                    }
                }
            }
            BillingClient.BillingResponseCode.SERVICE_DISCONNECTED,
            BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE,
            BillingClient.BillingResponseCode.BILLING_UNAVAILABLE,
            BillingClient.BillingResponseCode.ITEM_UNAVAILABLE,
            BillingClient.BillingResponseCode.DEVELOPER_ERROR,
            BillingClient.BillingResponseCode.ERROR -> {
                Log.e(LOG_TAG, "onSkuDetailsResponse: responseCode: $responseCode debugMessage: $debugMessage")
            }
            BillingClient.BillingResponseCode.USER_CANCELED,
            BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED,
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED,
            BillingClient.BillingResponseCode.ITEM_NOT_OWNED -> {
                // These response codes are not expected.
                Log.e(LOG_TAG, "onSkuDetailsResponse: responseCode: $responseCode debugMessage: $debugMessage")
            }
        }
    }

    fun acknowledgePurchase(purchaseToken: String) {
        Log.d(LOG_TAG, "acknowledgePurchase")
        val params = AcknowledgePurchaseParams.newBuilder()
            .setPurchaseToken(purchaseToken)
            .build()
        billingClient.acknowledgePurchase(params) { billingResult ->
            val responseCode = billingResult.responseCode
            val debugMessage = billingResult.debugMessage
            when (responseCode) {
                BillingClient.BillingResponseCode.OK -> {
                    purchaseRecordRepository.acknowledgePurchase(purchaseToken)
                }
                else -> Log.d(LOG_TAG, "acknowledgePurchase: responseCode: $responseCode " +
                        "debugMessage: $debugMessage")
            }
        }
    }

    fun consumePurchase(purchaseToken: String) {
        val params = ConsumeParams.newBuilder()
            .setPurchaseToken(purchaseToken)
            .build()
        billingClient.consumeAsync(params) { billingResult, s ->
            Log.d(LOG_TAG, "Consumed Purchase $s")
            val responseCode = billingResult.responseCode
            val debugMessage = billingResult.debugMessage
            when (responseCode) {
                BillingClient.BillingResponseCode.OK -> {
                    purchaseRecordRepository.consumePurchase(purchaseToken)
                }
                else -> Log.d(LOG_TAG, "consumePurchase: responseCode: $responseCode " +
                        "debugMessage: $debugMessage")
            }
        }
    }

    private fun queryProducts() {
        queryProducts(BillingClient.SkuType.SUBS, listOf(Constants.SUBSCRIPTION_SKU))
        queryProducts(BillingClient.SkuType.INAPP, listOf(
            Constants.CONSUMABLE_COUNTER_SKU,
            Constants.NON_CONSUMABLE_TIMER_SKU
        ))
    }

    /**
     * In order to make purchases, you need the [SkuDetails] for the item or subscription.
     * This is an asynchronous call that will receive a result in [onSkuDetailsResponse].
     */
    private fun queryProducts(productType: String, skuList: List<String>) {
        val params = SkuDetailsParams.newBuilder()
            .setType(productType)
            .setSkusList(skuList)
            .build()
        params?.let { skuDetailsParams ->
            Log.i(LOG_TAG, "Query $productType products")
            billingClient.querySkuDetailsAsync(skuDetailsParams, this)
        }
    }
    /**
     * Query Google Play Billing for existing purchases.
     *
     * New purchases will be provided to the PurchasesUpdatedListener.
     * You still need to check the Google Play Billing API to know when purchase tokens are removed.
     */
    private fun queryPurchases() {
        queryPurchases(BillingClient.SkuType.SUBS)
        queryPurchases(BillingClient.SkuType.INAPP)
    }

    private fun queryPurchases(type: String) {
        if (!billingClient.isReady) {
            Log.e(LOG_TAG, "queryPurchases: BillingClient is not ready")
        }
        Log.d(LOG_TAG, "queryPurchases: $type")
        val result = billingClient.queryPurchases(type)
        if (result == null) {
            Log.i(LOG_TAG, "queryPurchases: null purchase result")
            processPurchases(null)
        } else {
            if (result.purchasesList == null) {
                Log.i(LOG_TAG, "queryPurchases: null purchase list")
                processPurchases(null)
            } else {
                processPurchases(result.purchasesList)
            }
        }
        removeExpiredSubscription(type, result)
    }

    private fun removeExpiredSubscription(type: String, result: Purchase.PurchasesResult) {
        if (type == BillingClient.SkuType.SUBS) {
            if (result?.purchasesList?.firstOrNull { it.sku == Constants.SUBSCRIPTION_SKU } == null) {
                purchaseRecordRepository.deletePurchase(Constants.SUBSCRIPTION_SKU)
            }
        }
    }

    private fun processPurchases(purchasesList: List<Purchase>?) {
        purchasesList?.let {
            for (purchase in purchasesList) {
                when (purchase.sku) {
                    Constants.SUBSCRIPTION_SKU -> verifySubscriptionOnCloud(purchase)
                    Constants.CONSUMABLE_COUNTER_SKU,
                    Constants.NON_CONSUMABLE_TIMER_SKU -> verifyProductsOnCloud(purchase)
                    else -> {}
                }
            }
        }
    }

    private fun verifyProductsOnCloud(purchase: Purchase) {
        val firebaseFunctions = FirebaseFunctions.getInstance()
        val data = mapOf(
            "sku_id" to purchase.sku,
            "purchase_token" to purchase.purchaseToken,
            "package_name" to "com.pluralsight.counting"
        )
        firebaseFunctions.getHttpsCallable("verifyProducts").call(data).continueWith {
            try {
                val serverData = it.result?.data as? HashMap<String, Any>
                serverData?.get("productData")?.let { productData ->
                    Log.d(LOG_TAG, "$productData")
                    purchaseRecordRepository.createPurchaseRecord(purchase)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun verifySubscriptionOnCloud(purchase: Purchase) {
        val firebaseFunctions = FirebaseFunctions.getInstance()
        val data = mapOf(
            "sku_id" to purchase.sku,
            "purchase_token" to purchase.purchaseToken,
            "package_name" to "com.pluralsight.counting"
        )
        firebaseFunctions.getHttpsCallable("verifySubscription").call(data).continueWith {
            try {
                val serverData = it.result?.data as? HashMap<String, Any>
                serverData?.get("subscriptionData")?.let { subscriptionData ->
                    Log.d(LOG_TAG, "$subscriptionData")
                    purchaseRecordRepository.createPurchaseRecord(purchase)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun savePurchaseLocally(purchasesList: List<Purchase>) {
        for (purchase in purchasesList) {
            if (isSignatureValid(purchase)) {
                purchaseRecordRepository.createPurchaseRecord(purchase)
                Log.d(LOG_TAG, "savePurchaseLocally: ${purchase.sku} acknowledged=${purchase.isAcknowledged}"
                )
            } else {
                Log.d(LOG_TAG, "savePurchaseLocally: Signature is not valid: ${purchase.sku}")
            }
        }
    }

    private fun isSignatureValid(purchase: Purchase): Boolean {
        return security.verifyPurchase(security.BASE_64_ENCODED_PUBLIC_KEY, purchase.originalJson, purchase.signature)
    }
}
