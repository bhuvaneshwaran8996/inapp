package com.pluralsight.counting.ui.history.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.pluralsight.counting.R
import com.pluralsight.counting.db.log.Log
import java.text.SimpleDateFormat
import java.util.*

class HistoryItemAdapter : RecyclerView.Adapter<HistoryItemAdapter.ViewHolder>() {
    private var logs: List<Log> = mutableListOf()

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val logRowTextView: TextView = itemView.findViewById(R.id.history_row_text)

        fun bind(log: Log) {
            var result = if (log.count == null) "${log.duration} seconds" else log.count.toString()
            logRowTextView.text = "${getDateText(log.createdAt)}\n${log.counterName}\n$result"
        }

        private fun getDateText(millis: Long): String {
            val dateFormat = SimpleDateFormat()
            val date = Date(millis)
            return dateFormat.format(date)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView: View = LayoutInflater.from(parent.context).inflate(R.layout.history_row_item, parent, false)
        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int = logs.count()

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(logs[position])
    }

    fun setLogs(logs: List<Log>) {
        this.logs = logs
        notifyDataSetChanged()
    }
}
