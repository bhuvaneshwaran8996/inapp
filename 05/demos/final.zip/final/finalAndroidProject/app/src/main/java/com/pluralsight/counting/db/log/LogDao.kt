package com.pluralsight.counting.db.log

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface LogDao {
    @Insert
    fun insert(log: Log)

    @get:Query("SELECT * FROM log_table ORDER BY createdAt DESC")
    val allLogs: LiveData<List<Log>>
}
