package com.pluralsight.counting.ui.counter

import android.content.Context
import android.graphics.drawable.Drawable
import android.os.CountDownTimer
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.pluralsight.counting.R
import com.pluralsight.counting.db.log.LogRepository
import com.pluralsight.counting.model.CounterType
import java.lang.Math.min
import java.util.Date
import java.util.concurrent.TimeUnit

class CounterViewModel(
    private val logRepository: LogRepository
) : ViewModel() {
    private var countDownTimer: CountDownTimer? = null
    private var secondsUntilFinished: Long = 0L
    private val actualTimeElapsed: Long
        get() = min(countdownDuration, countdownDuration - secondsUntilFinished)
    var countingText: MutableLiveData<String> = MutableLiveData("")
    var isCountingDown: MutableLiveData<Boolean> = MutableLiveData(false)
    var counterId: String = ""
    var counterName: String = ""
    var number: Long = 0L
    var countdownDuration: Long = 0L
    var counterType: CounterType = CounterType.NUMBER

    fun increase() {
        number++
        countingText.postValue(number.toString())
    }

    fun reset() {
        when (counterType) {
            CounterType.NUMBER -> {
                number = 0L
                countingText.postValue(number.toString())
            }
            CounterType.DURATION -> {
                stopTimer()
                countingText.postValue(millisToText(TimeUnit.SECONDS.toMillis(countdownDuration)))
            }
        }
    }

    fun save() {
        when (counterType) {
            CounterType.NUMBER -> {
                logRepository.createLog(counterId, counterName, number, null, Date().time)
            }
            CounterType.DURATION -> {
                logRepository.createLog(counterId, counterName, null, actualTimeElapsed, Date().time)
            }
        }
        reset()
    }

    fun handleTimer() {
        if (isCountingDown.value == false) startTimer() else stopTimer()
    }

    private fun startTimer() {
        var duration = if (secondsUntilFinished > 0) secondsUntilFinished else countdownDuration
        countDownTimer = object : CountDownTimer(TimeUnit.SECONDS.toMillis(duration), TimeUnit.SECONDS.toMillis(COUNTDOWN_INTERVAL)) {
            override fun onFinish() {
                countingText.value = "Finish!"
                isCountingDown.postValue(false)
            }

            override fun onTick(millisUntilFinished: Long) {
                countingText.value = millisToText(millisUntilFinished)
                secondsUntilFinished = TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished)
            }
        }
        countDownTimer?.start()
        isCountingDown.postValue(true)
    }

    private fun stopTimer() {
        isCountingDown.postValue(false)
        countDownTimer?.cancel()
    }

    private fun millisToText(milliseconds: Long): String {
        return String.format(
            "%02d:%02d:%02d",
            TimeUnit.MILLISECONDS.toHours(milliseconds),
            TimeUnit.MILLISECONDS.toMinutes(milliseconds) - TimeUnit.HOURS.toMinutes(
                TimeUnit.MILLISECONDS.toHours(milliseconds)
            ),
            TimeUnit.MILLISECONDS.toSeconds(milliseconds) - TimeUnit.MINUTES.toSeconds(
                TimeUnit.MILLISECONDS.toMinutes(milliseconds)
            )
        )
    }

    fun getDrawable(context: Context): Drawable {
        return when (counterType) {
            CounterType.DURATION -> {
                if (isCountingDown.value == true) {
                    context.resources.getDrawable(R.drawable.ic_pause, null)
                } else {
                    context.resources.getDrawable(R.drawable.ic_start, null)
                }
            }
            CounterType.NUMBER -> context.resources.getDrawable(R.drawable.ic_add, null)
        }
    }

    companion object {
        private const val COUNTDOWN_INTERVAL = 1L
    }
 }
