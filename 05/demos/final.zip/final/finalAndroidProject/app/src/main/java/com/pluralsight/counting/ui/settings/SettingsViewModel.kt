package com.pluralsight.counting.ui.settings

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.pluralsight.counting.billing.Constants
import com.pluralsight.counting.db.purchase.PurchaseRecord
import com.pluralsight.counting.db.purchase.PurchaseRecordRepository

class SettingsViewModel(purchaseRecordRepository: PurchaseRecordRepository) : ViewModel() {
    private val purchaseRecords: LiveData<List<PurchaseRecord>> = purchaseRecordRepository.purchaseRecords

    fun hasActiveSubscription(): Boolean {
        val subscription = purchaseRecords.value?.firstOrNull { it.sku == Constants.SUBSCRIPTION_SKU && it.isAutoRenewing }
        return subscription != null
    }
}
