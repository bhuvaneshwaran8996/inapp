package com.pluralsight.counting.db.product

import android.content.Context
import androidx.annotation.WorkerThread
import androidx.lifecycle.LiveData
import com.android.billingclient.api.SkuDetails
import com.pluralsight.counting.db.localdb.CounterDatabase
import kotlinx.coroutines.*

class ProductRepository private constructor(private val application: Context) {
    private lateinit var counterDatabase: CounterDatabase

    companion object {
        private const val LOG_TAG = "ProductRepository"

        @Volatile
        private var INSTANCE: ProductRepository? = null

        fun getInstance(application: Context): ProductRepository =
            INSTANCE
                ?: synchronized(this) {
                INSTANCE
                    ?: ProductRepository(
                        application
                    )
                        .also { INSTANCE = it }
            }
    }

    val products: LiveData<List<Product>> by lazy {
        if (!::counterDatabase.isInitialized) {
            counterDatabase = CounterDatabase.getDatabase(application)
        }
        counterDatabase.productDao().allProducts
    }

    fun createProduct(skuDetails: SkuDetails) {
        val scope = CoroutineScope(Job() + Dispatchers.IO)
        scope.launch {
            insert(
                Product(
                    skuDetails.sku,
                    skuDetails.title,
                    skuDetails.description,
                    skuDetails.price,
                    skuDetails.priceCurrencyCode,
                    skuDetails.subscriptionPeriod,
                    skuDetails.freeTrialPeriod,
                    skuDetails.originalJson
                )
            )
        }
    }

    @WorkerThread
    private suspend fun insert(product: Product) = withContext(Dispatchers.IO) {
        if (!::counterDatabase.isInitialized) {
            counterDatabase = CounterDatabase.getDatabase(application)
        }
        counterDatabase.productDao().insert(product)
    }
}
