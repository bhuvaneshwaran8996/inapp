package com.pluralsight.counting.db.log

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.ForeignKey.CASCADE
import androidx.room.Index
import androidx.room.PrimaryKey
import com.pluralsight.counting.db.counter.Counter

@Entity(tableName = "log_table",
    indices = [Index("id"), Index("counterId")],
    foreignKeys = [ForeignKey(
    entity = Counter::class,
    parentColumns = arrayOf("id"),
    childColumns = arrayOf("counterId"),
    onDelete = CASCADE)]
)
class Log(
    @PrimaryKey
    var id: String,
    val counterId: String,
    val counterName: String,
    val count: Long?,
    val duration: Long?,
    val createdAt: Long
)
