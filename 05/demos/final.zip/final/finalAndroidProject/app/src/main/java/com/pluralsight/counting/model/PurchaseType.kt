package com.pluralsight.counting.model

enum class PurchaseType {
    NON_CONSUMABLE,
    CONSUMABLE,
    SUBSCRIPTION
}
