package com.pluralsight.counting.ui.home

import android.os.Bundle
import android.view.*
import android.widget.TextView
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pluralsight.counting.R
import com.pluralsight.counting.db.counter.Counter
import com.pluralsight.counting.model.CounterType
import com.pluralsight.counting.servicelocator.ServiceLocator
import com.pluralsight.counting.ui.home.recyclerview.CounterAdapter
import com.pluralsight.counting.ui.newcounter.NewCounterFragment
import com.pluralsight.counting.util.viewModelFactory

class HomeFragment : Fragment() {

    private lateinit var viewModel: HomeViewModel
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: CounterAdapter
    private lateinit var textView: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        setHasOptionsMenu(true)
        viewModel = ViewModelProvider(this,
            viewModelFactory {
                HomeViewModel(
                    ServiceLocator.counterRepository,
                    ServiceLocator.purchaseRecordRepository,
                    ServiceLocator.billingRepository
                )
            }
        ).get(HomeViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_home, container, false)
        textView = root.findViewById(R.id.fragment_home_text_empty_list)
        textView.visibility = if (viewModel.counters.value?.size ?: 0 > 0) View.GONE else View.VISIBLE
        recyclerView = root.findViewById(R.id.fragment_home_recyclerview)
        context?.let {
            recyclerView.layoutManager = LinearLayoutManager(it)
            adapter = CounterAdapter() { counter: Counter -> onCounterClicked(counter) }
            recyclerView.adapter = adapter
        }
        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel.counters.observe(viewLifecycleOwner, Observer { counters ->
            if (counters.isNullOrEmpty()) {
                viewModel.addDefaultCounter()
            }
            counters?.let {
                adapter.setCounters(counters)
                textView.visibility = if (viewModel.counters.value?.size ?: 0 > 0) View.GONE else View.VISIBLE
            }
            viewModel.updateCounterLimit()
        })
        viewModel.purchaseRecords.observe(viewLifecycleOwner, Observer {
            viewModel.consumePurchase()
            viewModel.updateCounterLimit()
        })
    }

    override fun onResume() {
        super.onResume()
        activity?.title = getString(R.string.title_home)
    }

    private fun onCounterClicked(counter: Counter) {
        val counterType: CounterType = CounterType.values()[counter.type]
        val bundle = bundleOf(SELECTED_COUNTER_ID to counter.id,
                                SELECTED_COUNTER_TYPE to counterType,
                                SELECTED_COUNTER_DURATION to counter.countDownDuration,
                                SELECTED_COUNTER_NAME to counter.name)
        findNavController().navigate(R.id.counter_dest, bundle, null)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_add_counter, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_add_counter) {
            if (viewModel.hasReachedCounterLimit) {
                Toast.makeText(context, getText(R.string.need_purchase_counter), Toast.LENGTH_LONG).show()
            } else {
                activity?.supportFragmentManager?.let {
                    NewCounterFragment().show(it, null)
                }
            }
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    companion object {
        const val SELECTED_COUNTER_ID: String = "SELECTED_COUNTER_ID"
        const val SELECTED_COUNTER_TYPE: String = "SELECTED_COUNTER_TYPE"
        const val SELECTED_COUNTER_NAME: String = "SELECTED_COUNTER_NAME"
        const val SELECTED_COUNTER_DURATION: String = "SELECTED_COUNTER_DURATION"
    }
}
