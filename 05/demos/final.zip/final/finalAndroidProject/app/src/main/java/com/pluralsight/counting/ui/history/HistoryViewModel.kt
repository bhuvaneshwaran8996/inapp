package com.pluralsight.counting.ui.history

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.pluralsight.counting.billing.BillingRepository
import com.pluralsight.counting.billing.Constants
import com.pluralsight.counting.db.log.Log
import com.pluralsight.counting.db.log.LogRepository
import com.pluralsight.counting.db.purchase.PurchaseRecord
import com.pluralsight.counting.db.purchase.PurchaseRecordRepository

class HistoryViewModel(
    logRepository: LogRepository,
    purchaseRecordRepository: PurchaseRecordRepository,
    private val billingRepository: BillingRepository
) : ViewModel() {
    val purchaseRecords: LiveData<List<PurchaseRecord>> = purchaseRecordRepository.purchaseRecords
    var logs: LiveData<List<Log>> = logRepository.logs

    val hasSubscribed: Boolean
        get() = purchaseRecords?.value?.firstOrNull { it.sku == Constants.SUBSCRIPTION_SKU }?.sku?.isNotEmpty() == true

    fun acknowledgePurchase() {
        purchaseRecords.value?.firstOrNull { it.sku == Constants.SUBSCRIPTION_SKU }?.let { subscriptionRecord ->
            if (!subscriptionRecord.isAcknowledged) {
                billingRepository.acknowledgePurchase(subscriptionRecord.purchaseToken)
            }
        }
    }
}
