package com.pluralsight.counting.db.counter

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CounterDao {
    @Insert
    fun insert(counter: Counter)

    @get:Query("SELECT * FROM counter_table")
    val allCounters: LiveData<List<Counter>>
}
