package com.pluralsight.counting.db.product

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "product_table", indices = [Index("sku")])
class Product(
    @PrimaryKey val sku: String,
    val title: String,
    val description: String,
    val price: String,
    val priceCurrencyCode: String,
    val subscriptionPeriod: String,
    val freeTrialPeriod: String,
    val jsonSkuDetails: String
)
