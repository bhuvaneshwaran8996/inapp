package com.pluralsight.counting.ui.newcounter

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.pluralsight.counting.R
import com.pluralsight.counting.model.CounterType
import com.pluralsight.counting.servicelocator.ServiceLocator
import com.pluralsight.counting.util.viewModelFactory

class NewCounterFragment : DialogFragment() {
    private lateinit var viewModel: NewCounterViewModel
    private lateinit var editTextName: EditText
    private lateinit var editTextDuration: EditText
    private lateinit var switchTimer: SwitchCompat

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.dialog_new_counter, null)
        editTextName = rootView.findViewById(R.id.editext_new_counter_name)
        editTextDuration = rootView.findViewById(R.id.editext_new_counter_duration)
        val textViewSeconds = rootView.findViewById<TextView>(R.id.textview_seconds)
        switchTimer = rootView.findViewById(R.id.switch_timer)
        switchTimer.setOnCheckedChangeListener { _, isChecked ->
            editTextDuration.visibility = if (isChecked) View.VISIBLE else View.INVISIBLE
            textViewSeconds.visibility = if (isChecked) View.VISIBLE else View.INVISIBLE
        }
        val buttonCancel = rootView.findViewById<TextView>(R.id.button_new_counter_cancel)
        buttonCancel.setOnClickListener { dismiss() }
        val buttonSave = rootView.findViewById<TextView>(R.id.button_new_counter_save)
        buttonSave.setOnClickListener {
            saveCounter()
            dismiss()
        }
        return rootView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this,
            viewModelFactory {
                NewCounterViewModel(
                    ServiceLocator.counterRepository,
                    ServiceLocator.purchaseRecordRepository,
                    ServiceLocator.billingRepository
                )
            }
        ).get(NewCounterViewModel::class.java)
        viewModel.purchaseRecords.observe(viewLifecycleOwner, Observer {
            viewModel.updatePurchasedTimers()
            switchTimer.isEnabled = viewModel.hasPurchasedTimer
            viewModel.acknowledgePurchase()
        })
    }

    private fun saveCounter() {
        val type = if (switchTimer.isChecked) CounterType.DURATION else CounterType.NUMBER
        val duration = getDuration(editTextDuration)
        val counterName =
            if (editTextName.text.toString().isEmpty()) "Counter" else editTextName.text.toString()
        viewModel.saveCounter(counterName, duration, type)
    }

    private fun getDuration(editTextDuration: EditText): Long {
        return try {
            editTextDuration.text.toString().toLong()
        } catch (ex: NumberFormatException) { 0 }
    }
}
