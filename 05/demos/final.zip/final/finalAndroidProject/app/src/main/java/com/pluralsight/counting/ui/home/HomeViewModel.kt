package com.pluralsight.counting.ui.home

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.pluralsight.counting.billing.BillingRepository
import com.pluralsight.counting.billing.Constants
import com.pluralsight.counting.db.counter.Counter
import com.pluralsight.counting.db.counter.CounterRepository
import com.pluralsight.counting.db.purchase.PurchaseRecordRepository

class HomeViewModel(
    private val counterRepository: CounterRepository,
    purchaseRecordRepository: PurchaseRecordRepository,
    private val billingRepository: BillingRepository
) : ViewModel() {
    private var purchasedCounterCounts = 0
    val counters: LiveData<List<Counter>> = counterRepository.counters
    val purchaseRecords = purchaseRecordRepository.purchaseRecords
    var hasReachedCounterLimit: Boolean = false

    fun updateCounterLimit() {
        purchasedCounterCounts = purchaseRecords.value?.filter { it.sku == Constants.CONSUMABLE_COUNTER_SKU }?.size ?: 0
        val maxCountersCount = MAX_FREE_COUNTER_COUNT + purchasedCounterCounts
        hasReachedCounterLimit = counters.value?.size ?: 0 >= maxCountersCount
    }

    fun consumePurchase() {
        purchaseRecords.value?.firstOrNull { it.sku == Constants.CONSUMABLE_COUNTER_SKU }?.let { purchaseRecord ->
            if (!purchaseRecord.isConsumed) {
                billingRepository.consumePurchase(purchaseRecord.purchaseToken)
            }
        }
    }

    fun addDefaultCounter() {
        if (counters.value?.isNullOrEmpty() == true) {
            Log.d("tag", "Add default counter")
            counterRepository.createCounter("Counter 1", duration = 0)
        } else {
            Log.d("tag", "counter size ${counters.value?.size}")
        }
    }

    companion object {
        private const val MAX_FREE_COUNTER_COUNT = 5
    }
}
