package com.pluralsight.counting.servicelocator

import android.content.Context
import com.pluralsight.counting.billing.BillingRepository
import com.pluralsight.counting.db.counter.CounterRepository
import com.pluralsight.counting.db.log.LogRepository
import com.pluralsight.counting.db.product.ProductRepository
import com.pluralsight.counting.db.purchase.PurchaseRecordRepository
import com.pluralsight.counting.util.Security

object ServiceLocator {

    private lateinit var context: Context

    fun initialize(ctx: Context) {
        context = ctx
    }

    val billingRepository by lazy { BillingRepository.getInstance(context,
                                                                productRepository,
                                                                purchaseRecordRepository,
                                                                Security) }
    val purchaseRecordRepository by lazy { PurchaseRecordRepository.getInstance(context) }
    val counterRepository by lazy { CounterRepository.getInstance(context) }
    val logRepository by lazy { LogRepository.getInstance(context) }
    val productRepository by lazy { ProductRepository.getInstance(context) }
}
