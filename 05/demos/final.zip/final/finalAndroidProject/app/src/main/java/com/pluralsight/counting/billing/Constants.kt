package com.pluralsight.counting.billing

object Constants {
    const val CONSUMABLE_COUNTER_SKU = "com.pluralsight.counting.counter"
    const val NON_CONSUMABLE_TIMER_SKU = "com.pluralsight.counting.timer"
    const val SUBSCRIPTION_SKU = "com.pluralsight.counting.subscription"
    const val PLAY_STORE_SUBSCRIPTION_DEEPLINK_URL =
            "https://play.google.com/store/account/subscriptions?sku=%s&package=%s"
    const val PLAY_STORE_OTHER_SUBSCRIPTION_URL = "https://play.google.com/store/account/subscriptions"
}
