package com.pluralsight.counting.db.localdb

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.pluralsight.counting.db.counter.Counter
import com.pluralsight.counting.db.counter.CounterDao
import com.pluralsight.counting.db.log.Log
import com.pluralsight.counting.db.log.LogDao
import com.pluralsight.counting.db.product.Product
import com.pluralsight.counting.db.product.ProductDao
import com.pluralsight.counting.db.purchase.PurchaseRecord
import com.pluralsight.counting.db.purchase.PurchaseRecordDao

@Database(entities = [Counter::class, Log::class, PurchaseRecord::class, Product::class], version = 1)
abstract class CounterDatabase : RoomDatabase() {
    abstract fun counterDao(): CounterDao
    abstract fun logDao(): LogDao
    abstract fun purchaseDao(): PurchaseRecordDao
    abstract fun productDao(): ProductDao

    companion object {
        @Volatile
        private var INSTANCE: CounterDatabase? = null

        fun getDatabase(context: Context): CounterDatabase {
            return INSTANCE
                ?: synchronized(this) {
                    var instance =
                        INSTANCE
                    if (instance == null) {
                        instance = Room.databaseBuilder(context.applicationContext,
                            CounterDatabase::class.java,
                            "counter_db")
                            .fallbackToDestructiveMigration()
                            .build()
                        INSTANCE = instance
                    }
                    instance!!
                }
        }
    }
}
