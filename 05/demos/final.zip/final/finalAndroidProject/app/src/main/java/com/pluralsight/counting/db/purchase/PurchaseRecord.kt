package com.pluralsight.counting.db.purchase

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "purchase_log_table")
class PurchaseRecord(
    @PrimaryKey
    val purchaseToken: String,
    val sku: String,
    val signature: String,
    val purchaseTime: Long,
    val purchaseState: Int,
    val originalJson: String,
    val isAcknowledged: Boolean,
    val isAutoRenewing: Boolean,
    val isConsumed: Boolean
)
