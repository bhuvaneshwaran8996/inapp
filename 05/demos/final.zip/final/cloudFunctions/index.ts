/*
* Reference: https://medium.com/@msasikanth/google-play-iap-verification-using-cloud-functions-bd8c3a22f9b9
*/
import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import * as key from './service-account-key.json';
import { google } from 'googleapis';
import { CallableContext } from 'firebase-functions/lib/providers/https';

admin.initializeApp();

const authClient = new google.auth.JWT({
    email: key.client_email,
    key: key.private_key,
    scopes: ["https://www.googleapis.com/auth/androidpublisher"]
});

const playDeveloperApiClient = google.androidpublisher({
    version: 'v3',
    auth: authClient
});

//Verify subscription purchase 
export const verifySubscription = functions.https.onCall(async (data, context: CallableContext) => {
    const skuId: string = data.sku_id;
    const purchaseToken: string = data.purchase_token;
    const packageName: string = data.package_name;

    try {
        await authClient.authorize();
        const subscription = await playDeveloperApiClient.purchases.subscriptions.get({
            packageName: packageName,
            subscriptionId: skuId,
            token: purchaseToken
        });

        if (subscription.status === 200) {
            // Subscription response is successful. subscription.data will return the subscription information.
            return {
                status: 200,
                subscriptionData: subscription.data,
                message: "Subscription verification successfuly!"
            }
        }
    } catch (error) {
        console.log(error)
    }

    // This message is returned when there is no successful response from the subscription/purchase get call
    return {
        status: 500,
        subscriptionData: null,
        message: "Failed to verify subscription - projectId: " + authClient.projectId + ", email " + authClient.email
    }
});

//Verify one-time products purchase 
export const verifyProducts = functions.https.onCall(async (data, context: CallableContext) => {
    const skuId: string = data.sku_id;
    const purchaseToken: string = data.purchase_token;
    const packageName: string = data.package_name;

    try {
        await authClient.authorize();
        const product = await playDeveloperApiClient.purchases.products.get({
            packageName: packageName,
            productId: skuId,
            token: purchaseToken
        });

        if (product.status === 200) {
            // product response is successful. product.data will return the product information.
            return {
                status: 200,
                productData: product.data,
                message: "product verification successfuly!"
            }
        }
    } catch (error) {
        console.log(error)
    }

    // This message is returned when there is no successful response from the product/purchase get call
    return {
        status: 500,
        productData: null,
        message: "Failed to verify product - projectId: " + authClient.projectId + ", email " + authClient.email
    }
});

/* PubSub listener which handle Realtime Developer Notifications received from Google Play.
 * See https://developer.android.com/google/play/billing/realtime_developer_notifications.html
 */
export const realtime_notification_listener = functions.pubsub.topic('play-subs').onPublish(async (data, context) => {
    try {
      // Process the Realtime Developer notification
      const developerNotification = <DeveloperNotification>data.json;
      const subscription = developerNotification.subscriptionNotification;
      const notificationType = subscription ? subscription.notificationType : "";
      const subscriptionId = subscription ? subscription.subscriptionId : "";
      const token = subscription ? subscription.purchaseToken : "";
      console.log('Received realtime notification: ', subscriptionId + ", type: " + notificationType + ", token: " + token);
    } catch (error) {
      console.error(error);
    }
  });
  
    
// As defined in https://developer.android.com/google/play/billing/rtdn-reference#encoding
export interface DeveloperNotification {
    version: string,
    packageName: string
    eventTimeMillis: number
    subscriptionNotification?: SubscriptionNotification
    testNotification?: TestNotification
  }
  
  // As defined in https://developer.android.com/google/play/billing/rtdn-reference#sub
  export interface SubscriptionNotification {
    version: string
    notificationType: NotificationType
    purchaseToken: string
    subscriptionId: string
  }
  
  // As defined in https://developer.android.com/google/play/billing/rtdn-reference#test
  export interface TestNotification {
    version: string
  }
  
  // As defined in https://developer.android.com/google/play/billing/rtdn-reference#notification_types
  export enum NotificationType {
    SUBSCRIPTION_RECOVERED = 1,
    SUBSCRIPTION_RENEWED = 2,
    SUBSCRIPTION_CANCELED = 3,
    SUBSCRIPTION_PURCHASED = 4,
    SUBSCRIPTION_ON_HOLD = 5,
    SUBSCRIPTION_IN_GRACE_PERIOD = 6,
    SUBSCRIPTION_RESTARTED = 7,
    SUBSCRIPTION_PRICE_CHANGE_CONFIRMED = 8,
    SUBSCRIPTION_DEFERRED = 9,
    SUBSCRIPTION_PAUSED = 10,
    SUBSCRIPTION_PAUSE_SCHEDULE_CHANGED = 11,
    SUBSCRIPTION_REVOKED = 12,
    SUBSCRIPTION_EXPIRED = 13
  }